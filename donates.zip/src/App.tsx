import React, {useState} from 'react';
import './App.css';
import {useInterval} from "./helpers";

const REQUEST_DATA = { "last_id": -1 };

// Parameters for displaying
const TARGET_PK = 'BC1YLg7BTSVWu4UUVZUrpGjUQgecTmeZVcbCTZs1FX1mWipSbZKyJ2j'; //todo from page params if possible in obs
const POLLING_INTERVAL = 3000;
const TITLE = '@Alisher'

//Transaction interface
interface Transfer {
    id: number,
    amount: number,
    from_pk: string,
    from_username: string,
    to_pk: string,
    to_username: string,
    coin: string,
}

interface BuySellTransaction {
    action: string,
    actor_pk: string,
    actor: string,
    target_pk: string
    amount: number,
    id: number,
}

function App() {
    const [ transfers, setTransfers ] = useState<any>([]);
    const [ lastId, setLastId ] = useState(-1);

    const [ coinsData, setCoinsData ] = useState<any>([]);
    const [ coinsLastId, setCoinsLastId] = useState(-1);

    useInterval(() => {
        fetch('http://185.20.226.75:5050/mempool/transfer/get', { method: 'post', body: JSON.stringify(REQUEST_DATA) })
            .then(res => res.json())
            .then(data => {
                // filter only new transactions for target user
                const newUserTransactions = data.transfers.filter((transaction: Transfer) => transaction.to_pk === TARGET_PK && transaction.id > lastId);
                if (newUserTransactions.length) {
                    setTransfers([ ...transfers, ...newUserTransactions ]);
                    setLastId(newUserTransactions[newUserTransactions.length - 1].id);
                }
            })
            .catch(e => console.log(e));
        fetch('http://185.20.226.75:5050/mempool/coins/get', { method: 'post', body: JSON.stringify(REQUEST_DATA) })
            .then(res => res.json())
            .then(data => {
                console.log(data)
                // filter only new transactions for target user
                const newUserTransactions = data.transactions.filter((transaction: BuySellTransaction) => transaction.target_pk === TARGET_PK && transaction.id > coinsLastId);
                if (newUserTransactions.length) {
                    setCoinsData([ ...coinsData, ...newUserTransactions ]);
                    setCoinsLastId(newUserTransactions[newUserTransactions.length - 1].id);
                }
            })
            .catch(e => console.log(e));
    }, POLLING_INTERVAL);

    return (
        <div className="App">
            <div className="title">{TITLE}</div>
            {
                transfers &&
                transfers.slice(0).reverse().map((transaction: Transfer) => {
                    return (
                        <div className="message" key={transaction.id}>
                            <span className="messageActor">@{transaction.from_username}</span>
                            <div className="action">
                                <span> transfer</span>
                                <span> {transaction.amount}</span>
                                {
                                    transaction.coin &&
                                    <span> {transaction.coin}</span>
                                }
                            </div>
                        </div>
                    )
                })
            }
            {
                coinsData &&
                coinsData.slice(0).reverse().map((transaction: BuySellTransaction) => {
                    return (
                        <div className="message" key={transaction.id}>
                            <span className="messageActor">@{transaction.actor}</span>
                            <div className="action">
                                <span> {transaction.action}</span>
                                <span> {transaction.amount}</span>
                            </div>
                        </div>
                    )
                })
            }
        </div>
    );
}

export default App;
